// window.onload = function () {
//   function e(e) {
//     return (
//       e.stopPropagation
//         ? e.stopPropagation()
//         : window.event && (window.event.cancelBubble = !0),
//       e.preventDefault(),
//       !1
//     );
//   }
//   document.addEventListener(
//     "contextmenu",
//     function (e) {
//       e.preventDefault();
//     },
//     !1
//   ),
//     document.addEventListener(
//       "keydown",
//       function (t) {
//         t.ctrlKey && t.shiftKey && 73 == t.keyCode && e(t),
//           t.ctrlKey && t.shiftKey && 74 == t.keyCode && e(t),
//           83 == t.keyCode &&
//             (navigator.platform.match("Mac") ? t.metaKey : t.ctrlKey) &&
//             e(t),
//           t.ctrlKey && 85 == t.keyCode && e(t),
//           123 == event.keyCode && e(t);
//       },
//       !1
//     );
// };
